import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import com.IO.inputoutput;
import com.excel.writeData;
import utilities.propertiesfile;
import java.time.Duration;
import java.time.Instant;
	
public class test {
	public static void main(String[] args) throws InvalidFormatException, IOException {
		// TODO Auto-generated method stub
		
		Instant start = Instant.now();
		
		String filepath1,filepath2;
		
		//filepath1 = new propertiesfile().readProperties("path1folder");
		//filepath2 = new propertiesfile().readProperties("path2folder");
		
		//filepath1 = System.getProperty("user.home") + "/Desktop/CSS";
		//filepath2 = System.getProperty("user.home") + "/Desktop/SAP";
		
		filepath1 = "C:/Users/MXO0GKC/PDF/CSS";
		filepath2 = "C:/Users/MXO0GKC/PDF/SAP";
		
		//create excel file
		new writeData("pdf.xls");	
		//loop all the files in folder1 1= CSS
		new inputoutput(filepath1,1,"\\pdf.xls");
		//loop all the files in folder2 2=SAP
		new inputoutput(filepath2,2,"\\pdf.xls");
		
		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMinutes(); 
		System.out.println("Finished in "+timeElapsed+ " minutes");
	}		
}
