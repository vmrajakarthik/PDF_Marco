import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import com.IO.inputoutput;
import com.excel.writeData;
import utilities.propertiesfile;
	
public class thread2 extends Thread {
	
	
	public void run() {
		// TODO Auto-generated method stub
		
		try {
		String filepath2;
		
		//filepath1 = new propertiesfile().readProperties("path1folder");
		filepath2 = new propertiesfile().readProperties("path2folder");
		
		//create excel file
		new writeData("SAP.xls");	
		//loop all the files in folder1
	
			new inputoutput(filepath2,2,"\\SAP.xls");
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}		

}
