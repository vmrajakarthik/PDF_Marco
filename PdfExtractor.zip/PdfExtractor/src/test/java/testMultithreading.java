public class testMultithreading {
	
	
	public static void main(String[] args) 
    { 
		
		thread1 object1 = new thread1(); 
        object1.start();
        
        thread2 object2 = new thread2(); 
        object2.start();
	
    } 

}
