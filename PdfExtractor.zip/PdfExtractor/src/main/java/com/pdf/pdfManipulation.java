package com.pdf;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class pdfManipulation {
	
	public String[] toArray(String text) {
		String lines[] = text.split("\\r?\\n");
		return lines;
	}
	
	public String getPdfType1(String[] arr) {
		List<String> arr1 = Arrays.asList(arr);
		String pdfType;
		
		List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Current Electric Service -.*");
		if(b.isEmpty()) {
			int a = arr1.indexOf("Current Electric Service")+2;
  			String c = arr1.get(a).toString().trim().substring(0, 2);
  			pdfType = c;
		}else {
		String[] a = b.get(0).toString().trim().split("-");
		pdfType = a[1].toString().trim();
		}	
		
		return pdfType;	
	}
	
	public String getPdfType2(String[] arr) {
		List<String> arr1 = Arrays.asList(arr);
		String pdfType;
		
		List<String> b = new pdfUtility().getMatchingStrings(arr1,"Rate:.*");
		String a = b.get(0).toString().trim();
		String c = StringUtils.substringBetween(a, ":","-").trim();
		pdfType = c;	
		
		return pdfType;	
	}
	
}
