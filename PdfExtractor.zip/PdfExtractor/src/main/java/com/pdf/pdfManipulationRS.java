package com.pdf;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class pdfManipulationRS {

		
	public HashMap<Integer, String> getFields1(String[] arr,int pdfNum, String fname,String pdfType) {
		HashMap<Integer,String> myMap=new HashMap<Integer,String>();
		List<String> arr1 = Arrays.asList(arr);
	
      try {
          
    	String sMeterreading;
    	//String pdfType;
    	
    	//put the filename into the map
    	{
    		myMap.put(0,fname.trim());
    	}
    	
  		//Get Service Type with two types
  		/*{	
  			
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Current Electric Service -.*");
  			if(b.isEmpty()) {
  				int a = arr1.indexOf("Current Electric Service")+2;
  	  			String c = arr1.get(a).toString().trim().substring(0, 2);
  	  			myMap.put(6,c);
  	  			pdfType = c;
  			}else {
	  			String[] a = b.get(0).toString().trim().split("-");
	  			myMap.put(6,a[1].toString().trim());
	  			pdfType = myMap.get(6);
  			}	
  		}*/
  		//logic to handle short forms of service types
  		{
  			if(pdfType.equalsIgnoreCase("RS")) {
  				//pdfType = "RS";
  				myMap.put(44,"RS");
  			}
  		}
  		
    	//logic for USAGE field - 24
  		{
  		int a = arr1.indexOf("Days In Billing Period")+1;
  		String b[] = arr1.get(a).toString().trim().split(" ");
  		myMap.put(49,b[0].replace(",",""));
  		
  		//to be reused for other fields
  		sMeterreading = b[0].replace(",","");
  		}
  		
  		
    	//Delinquent After
  		{
  			List<Integer> b = new pdfUtility().getMatchingStringsindex(arr1,"Delinquent After");
  			if(b.isEmpty()) {
  				myMap.put(9,"NA");
  				myMap.put(43,"NA");
  				myMap.put(16,"NA");
  			}else {
  			
  			String a = arr1.get(b.get(0).intValue()-2).toString().trim();
  			myMap.put(9,a);
  			a = arr1.get(b.get(1).intValue()-2).toString().trim();
  			myMap.put(43,a);	
  			a = arr1.get(b.get(2).intValue()-2).toString().trim();
  			myMap.put(16,a);	
  			}
  		}
  			
  		//Meter # Sep 6 - Oct 8 2,0005853270 Tot kWh 89876 87876 1  - use Usage
  		{
  		int a = arr1.indexOf("Meter Reading")+1;
  		String b[] = arr1.get(a).toString().trim().split(" ");
  		String[] c= b[5].replace(",","").split(sMeterreading);
  		myMap.put(45,c[1].replace(",",""));	
  		}

  		//Customer Name
  		{
  			int a = arr1.indexOf("Page  of 1 2")+1;
  			int b = arr1.indexOf("Page  of 2 2")+1;
  			String c = arr1.get(a).replaceAll("[0-9]|-", "").trim();
  			String d = arr1.get(b).replaceAll("[0-9]|-", "").trim();
  			myMap.put(1,c);
  			myMap.put(2,d);
  		}
  		
  		//Account Number 
  		{
  			int a = arr1.indexOf("Page  of 1 2")+1;
  			int b = arr1.indexOf("Page  of 2 2")+1;
  			String[] c = arr1.get(a).trim().split(" ");
  			String[] d = arr1.get(b).trim().split(" ");
  			myMap.put(3,c[c.length-1]);
  			myMap.put(4,d[d.length-1]);
  			
			List<String> e = new pdfUtility().getMatchingStrings(arr1,"Account number:.*");
  			String[] f = e.get(0).toString().trim().split(":");
  			myMap.put(41,f[1].toString().trim());	
  		}
  		
  		
  		
  		//account number and web access code
  		/*{
  			int a = arr1.indexOf("Emergencies: 24hrs/7 days")+1;
  			String b[] = arr1.get(a).toString().trim().split(":");
  			String c[] = arr1.get(a+1).toString().trim().split(":");
  			myMap.put(3,b[1].trim());
  			//myMap.put(4,c[1]); webaccess code not applcatble in new file
  		}*/
  		
  		//Get Service Address 5
  		{
  			int a = arr1.indexOf("Service Address")+1;
  			String b = arr1.get(a).toString().trim();
  			myMap.put(5,b);
  		}
  		
  		//Get Service Period 7
  		{
  			int a = arr1.indexOf("Service Period")+1;
  			String b = arr1.get(a).toString().trim();
  			String[] c= b.split("-");
  			myMap.put(6,c[0]);
  			myMap.put(7,c[1]);
  		}
  		
  		//Get Pervious Bill Amount
  		{	
  		
  		List<String> b = new pdfUtility().getMatchingStrings(arr1,"Previous Bill Amount.*");
		if(b.isEmpty()) {
			myMap.put(11,"NA");
		}else {
			String[] a = b.get(0).toString().trim().split("Amount");
  			myMap.put(11,a[1]);
		}
			
  		}
  		
  		//Get Payment REceived On #1 and Amount
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Payment Received On.*");
  			if(b.isEmpty()) {
  				myMap.put(12,"NA");
  				myMap.put(10,"NA");
  			}else {
  				String a = b.get(0).toString().trim();
  	  			String c = StringUtils.right(a, 8);
  	  			myMap.put(12,c);
  	  			myMap.put(10,"$"+StringUtils.substringBetween(a, "-", c));
  			}
  			
  			
  			
  		}
  				

  		
  		//Get Base Charge
  		{	
  			if(pdfType.equalsIgnoreCase("RS")) {
  				List<String> b = new pdfUtility().getMatchingStrings(arr1,"Base Charge.*");
  	  			String[] a = b.get(0).toString().trim().split("\\$");
  	  			myMap.put(61,"$"+a[1].toString().trim());	
  			}
  			
  		}
  		
  		//Get Energy Charge
  		{	
 			if(pdfType.equalsIgnoreCase("RS")) {
 	  			List<String> c = new pdfUtility().getMatchingStrings(arr1,"Energy Charge.*");
 	  			String[] d = c.get(0).toString().trim().split(" ");
 	  			myMap.put(70,"$"+d[2].toString().trim().replace(sMeterreading,""));
  			}
  		 	//int a = arr1.indexOf("Days In Billing Period")+1;
  			//String b[] = arr1.get(a).toString().trim().split(" ");
  			//String sMeterreading = b[0].replace(",","");
  		}
  		
  		//Get Fuel Charge
  		{
  			//int a = arr1.indexOf("Days In Billing Period")+1;
  			//String b[] = arr1.get(a).toString().trim().split(" ");
  			//String sMeterreading = b[0].replace(",","");
  			
  			if(pdfType.equalsIgnoreCase("RS")) {
  				List<String> c = new pdfUtility().getMatchingStrings(arr1,"Fuel Charge.*");
  	  			String[] d = c.get(0).toString().trim().split(" ");
  	  			myMap.put(71,"$"+d[2].toString().trim().replace(sMeterreading,""));
  			}
  		}
  		
  		
  		//Get Subtotal 
  		{	
  			if(pdfType.equalsIgnoreCase("RS")) {
  				List<String> b = new pdfUtility().getMatchingStrings(arr1,"Subtotal of Electric Service.*");
  	  			String[] a = b.get(0).toString().trim().split("\\$");
  	  			myMap.put(17,"$"+a[1].toString().trim());
  			}
  		}
  		
  		//State Sales Tax - Lighting
  		{	
  			if(pdfType.equalsIgnoreCase("RS")) {
  	  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Lighting.*");
  	  			if(b.isEmpty()) {
  	  				myMap.put(81,"0");
  	  			}else {
  	  			String[] a = b.get(0).toString().trim().split("Lighting");
  	  			myMap.put(81,"$"+a[1].toString().trim());
  	  			}
  			}
  		}
  		
  		//Get County Sales Tax
  		{	
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*County Local Sales Tax.*");
  			if(b.isEmpty()) {
  				myMap.put(77,"0");
  			}else {
  			String[] a = b.get(0).toString().trim().split(" ");
  			myMap.put(77,"$"+a[4].toString().trim());
  			}
		}
  		
  		
  			
  		
  		
  		//Get Florida Gross Receipts tax
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Florida Gross Receipts Tax.*");
  			if(b.isEmpty()) {
  				myMap.put(73,"0");
  			}else {
  			String[] a = b.get(0).toString().trim().split("Tax");
  			myMap.put(73,"$"+a[1].toString().trim());
  			}
  		}
  		
  		//Get Franchise Fee
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Franchise Fee.*");
  			if(b.isEmpty()) {
  				myMap.put(74,"0");
  			}else {
  				String[] a = b.get(0).toString().trim().split(" ");
  	  			myMap.put(74,"$"+a[a.length-1].trim().toString().trim());
  			}
  		}
  		
  		//Total Electric Service 23
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total Current Electric.*");
  			if(b.isEmpty()) {
  				myMap.put(79,"0");
  			}else {
  				String[] a = b.get(0).toString().trim().split("\\$");
  				myMap.put(79,"$"+a[1].toString().trim());
  			}
  		}
  		
  		//Total Due near current electric service
  		{	
  			List<Integer> b = new pdfUtility().getMatchingStringsindex(arr1,"Total Due");
  			if(b.isEmpty()) {
  				myMap.put(8,"NA");
  				myMap.put(42,"NA");
  				myMap.put(83,"NA");
  			}else {
  			String a = arr1.get(b.get(0).intValue()+1).toString().trim();
  			myMap.put(8,a);
  			String c = arr1.get(b.get(1).intValue()+1).toString().trim();
  			myMap.put(42,c);
  			String d = arr1.get(b.get(2).intValue()+1).toString().trim();
  			myMap.put(83,d);
  			}
  		}
  		
  		//Total Due near Delinquent
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total Due .*");
  			if(b.isEmpty()) {
  				myMap.put(10,"NA");
  			}else {
  				String[] a = b.get(0).toString().trim().split(" ");
  	  			myMap.put(10,"$"+a[a.length-1].toString().trim());
  			}		
  		}
  		
  		//Current reading and Previous reading
  		{
  			int a = arr1.indexOf("Meter Reading")+1;
  			String c[] = arr1.get(a).toString().trim().split("kWh");
  			String b[] = c[1].toString().trim().split(" ");
  			myMap.put(47,b[0].toString().trim());
  			myMap.put(48,b[1].toString().trim());
  			
  		}
    	
  		//yet to code due to insufficient data
  		//myMap.put(12," "); //Budget Billing
  		//myMap.put(75,"NA"); //State Sales Tax
  		
  		//Past due electric service
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Past Due Electric Service.*");
  			if(b.isEmpty()) {
  				myMap.put(13,"NA");
  			}else {
  				String[] a = b.get(0).toString().trim().split("Past");
  				myMap.put(13,a[0].toString().trim());
  			}
  		}
  		
  		//Next Scheduled Read Date
  		{	
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Next Scheduled Read Date.*");
  			if(b.isEmpty()) {
  				myMap.put(46,"NA");
  			}else {
  			String[] a = b.get(0).toString().trim().split("after");
  			myMap.put(46,a[1].toString().trim());
  			}
		}
  		
  		//Next meter reading 
			/*
			 * { List<String> b = new
			 * pdfUtility().getMatchingStrings(arr1,".*Next meter reading.*");
			 * if(b.isEmpty()) { myMap.put(33,"NA"); }else { String[] a =
			 * b.get(0).toString().trim().split("Next meter reading");
			 * myMap.put(33,a[a.length-1].toString().trim()); } }
			 */
  		
  		//Current Electric Service Amount
  		{	
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Current Electric Service .*");
  			if(b.isEmpty()) {
  				myMap.put(78,"NA");
  			}else {
  			String[] a = b.get(0).toString().trim().split("Service");
  			myMap.put(78,a[1].toString().trim());
  			}
		}
  		
  		//City tax
  		{	
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"City Tax for.*");
  			if(b.isEmpty()) {
  				myMap.put(76,"NA");
  			}else {
  			String[] a = b.get(0).toString().trim().split(" ");
  			myMap.put(76,a[a.length-1].toString().trim());
  			}
		}
  		
  		
  		
       } catch(ArrayIndexOutOfBoundsException e) {
          System.out.println(e.getMessage());
       }
		
	
		return myMap;
	}
	
	public HashMap<Integer, String> getFields2(String[] arr,int pdfNum, String fname, String pdfType) {
		HashMap<Integer,String> myMap=new HashMap<Integer,String>();
		List<String> arr1 = Arrays.asList(arr);
		
		 try {
	          //String pdfType;
		//put the name into the map
		{
			myMap.put(0,fname.trim());
		}
			 
		
		//logic to handle short forms of service types
  		{
  			if(pdfType.equalsIgnoreCase("RS")) {
  				//pdfType = "RS";
  				myMap.put(37,"RS");
  			}
  		}
		
		
		//Get Usage
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"kWh used.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(36,a[2].toString().trim());
		}
		
		//Meter No
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Meter reading - Meter.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(32,a[4].toString().trim().replaceAll("\\.", ""));
		}
		
		//customer name page 1 
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Hello.*");
			String[] a = b.get(0).toString().trim().split("Hello");
			myMap.put(1,a[1].toString().trim().replaceAll(",",""));
		}
		
		
			
		//customer name page 2
		{
			List<Integer> b = new pdfUtility().getMatchingStringsindex(arr1,".*Page 2.*");
			String a = arr1.get(b.get(0).intValue()+1).toString().trim();
			String c = a.replaceAll("[0-9]|-", "").trim();
			myMap.put(2,c);
		}
			
			
		//Account number
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Account Number:.*");
			String[] a = b.get(0).toString().trim().split(":");
			myMap.put(3,a[1].toString().trim());
		}
		
		//Account number page 2
		{
			List<Integer> b = new pdfUtility().getMatchingStringsindex(arr1,".*Page 2.*");
			String a = arr1.get(b.get(0).intValue()+1).toString().trim();
			String c = a.replaceAll("[a-zA-Z]", "").trim();
			myMap.put(4,c);
		}
		
		//Account number Stub
		{
			int a = arr1.indexOf("Here's what you owe for this billing period.")+1;
			String[] b = arr1.get(a).trim().split(" ");
			myMap.put(29,b[0]);
		}
		
		//Web Access code
		{	
			//Not in SAP Phase 1
			//myMap.put(4,"N/A");
		}
		
		//Service Address:
		{
			int a = arr1.indexOf("Service Address:")+1;
			String b = arr1.get(a).trim();
			myMap.put(5,b);
		}
		
		//Get Service Period 7
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"For.*");
			String[] a = b.get(0).toString().trim().split(":");
			String[] c = a[1].split("\\(");
			myMap.put(7,c[0].toString().trim().replaceAll("to","-"));
		}
		
		//Amount of your last bill
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Amount of your last bill.*");
			String[] a = b.get(0).toString().trim().split("last bill");
			myMap.put(9,"$"+a[1].toString().trim());
			a = b.get(1).toString().trim().split("last bill");
			myMap.put(11,"$"+a[1].toString().trim());
		}
		

		
		//Base Charge
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Base charge.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(38,"$"+a[2].toString().trim());
		}
		
		//Energy Charge 
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Energy charge.*");
			String[] a = b.get(0).toString().trim().split(" ");
			if(a.length==7){
				myMap.put(47,a[6].toString().trim());
				myMap.put(48,a[2].toString().trim());
				myMap.put(49,a[5].toString().trim());
			}else {
				myMap.put(47,"NA");
				myMap.put(48,"NA");
				myMap.put(49,"NA");
			}
		}
		
		//Fuel Charge [Fuel charge 852 KWH at $0.03047 25.96]
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Fuel charge.*");
			String[] a = b.get(0).toString().trim().split(" ");
			if(a.length==7){
				myMap.put(50,a[6].toString().trim());
				myMap.put(51,a[2].toString().trim());
				myMap.put(52,a[5].toString().trim());
			}else {
				myMap.put(50,"NA");
				myMap.put(51,"NA");
				myMap.put(52,"NA");
			}
		}
		
		//Get SubTotal
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Electric service amount .*");
			String[] a = b.get(0).toString().trim().split("amount");
			myMap.put(53,a[1].toString().trim());
		}
		
		//State Sales Tax
		{	
			//Not in SAP Phase 1
			//myMap.put(18,"N/A");
		}
		
		//Last Payment recived on
		{	
			//Not in SAP Phase 1
			//myMap.put(9,"N/A");
		}
		
		//Get Florida Gross Receipts tax Gross Receipts 3.01
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Gross receipts.*");
			if(b.isEmpty()) {
				 b = new pdfUtility().getMatchingStrings(arr1,"Gross Receipts.*");
				 String[] a = b.get(0).toString().trim().split("Receipts");
	  			myMap.put(54,"$"+a[1].toString().trim());
 			}else {
 				String[] a = b.get(0).toString().trim().split("tax");
 				myMap.put(54,"$"+a[1].toString().trim());
 			}

		}
		
		
		
		//Franchise Fee City Franchise Fee 6.18
		{	
			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Franchise charge.*");
			if(b.isEmpty()) {
				 b = new pdfUtility().getMatchingStrings(arr1,".*Franchise Fee.*");
				 String[] a = b.get(0).toString().trim().split("Fee");
	  			myMap.put(55,"$"+a[1].toString().trim());
  			}else {
  				String[] a = b.get(0).toString().trim().split("charge");
  				myMap.put(55,"$"+a[1].toString().trim());
  			}	
		}

		//Get  Total new charges 1
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total new charges.*");
			String[] a = b.get(1).toString().trim().split("charges");
			myMap.put(61,a[1].toString().trim());
		}
		
		//Get  Total new charges 2
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total new charges.*");
			String[] a = b.get(0).toString().trim().split("charges");
			myMap.put(66,a[1].toString().trim());
		}
		
		//Total Due 13 Total amount due $92.36
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total amount due.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(14,a[a.length-1]);
		}
		
		//Payment Received Amount 10
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*received.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(10,"$"+a[a.length-1].toString().trim().substring(1));
			a = b.get(1).toString().trim().split(" ");
			myMap.put(12,"$"+a[a.length-1].toString().trim().substring(1));
		}
		
		
  		//yet to code 
		//Not in SAP Phase 1
  		//myMap.put(11," ");//Current Electric Service
  		//myMap.put(12," ");//Budget Billing
  		//myMap.put(21," ");//State Sales Tax
  		//myMap.put(22," ");//County Sales Tax
		
		//current reading
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Current reading.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(34,a[2].toString().trim());	
  			
  		}
  		
  		//previous reading
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Previous reading.*");
			String[] a = b.get(0).toString().trim().split("-");
			myMap.put(35,a[1].toString().trim());		
  		}
  		
  		//Balance before new Charges
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Balance.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(65,a[a.length-1].toString().trim());
			String[] c = b.get(1).toString().trim().split(" ");
			myMap.put(65,c[c.length-1].toString().trim());	
  		}
  		
		//TOTAL AMOUNT OWED
		{
			int a = arr1.indexOf("Here's what you owe for this billing period.")+1;
			String[] b = arr1.get(a).trim().split(" ");
			myMap.put(30,b[1]);
		}
		
		//TOTAL AMOUNT you Owe
		{
			int a = arr1.indexOf("TOTAL AMOUNT YOU OWE")-1;
			String b = arr1.get(a).trim();
			myMap.put(8,b);
		}
		
		//NEW CHARGES DUE BY
		{
			int a = arr1.indexOf("NEW CHARGES DUE BY")-1;
			String b = arr1.get(a).trim();
			myMap.put(7,b);
		}
		
		//NEW CHARGES DUE BY STUB
		{
			int a = arr1.indexOf("Here's what you owe for this billing period.")+1;
			String[] b = arr1.get(a).trim().split(" ");
			String c = b[1].replaceAll("[^a-zA-Z0-9.]+","");
			String[] d = arr1.get(a).trim().split(c);
			myMap.put(31,d[1].replace("$", ""));
		}
  		
		//Taxes and charges
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Taxes and charges.*");
			if(b.isEmpty()) {
	  			myMap.put(60,"NA");
 			}else {
 				String[] a = b.get(0).toString().trim().split(" ");
 				myMap.put(60,a[a.length-1].toString().trim());
 			}
		}
		
		//Total amount you Owe
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total amount you owe .*");
			if(b.isEmpty()) {
	  			myMap.put(62,"NA");
 			}else {
 				String[] a = b.get(0).toString().trim().split(" ");
 				myMap.put(62,a[a.length-1].toString().trim());
 			}
		}
		
		
		
		//Utility Tax
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Utility.*");
			if(b.isEmpty()) {
	  			myMap.put(57,"NA");
 			}else {
 				String[] a = b.get(0).toString().trim().split(" ");
 				myMap.put(57,a[a.length-1].toString().trim());
 			}
		}
		
		//IS PAST DUE
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*IS PAST DUE.*");
			if(b.isEmpty()) {
	  			myMap.put(15,"NA");
	  			myMap.put(64,"NA");
 			}else {
 				String[] a = b.get(0).toString().trim().split(" ");
 				myMap.put(15,a[1].toString().trim());
 				String[] c = b.get(1).toString().trim().split(" ");
 				myMap.put(64,c[1].toString().trim());
 			}
		}
		
		//IS PAST DUE
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Meter reading.*");
			if(b.isEmpty()) {
	  			myMap.put(33,"NA");
 			}else {
 				String[] a = b.get(0).toString().trim().split("Next meter reading");
 				myMap.put(33,a[1].toString().trim());
 			}
		}
		
		//Electric Bill Statement
		{
			int a = arr1.indexOf("Electric Bill Statement")+1;
			String[] b = arr1.get(a).trim().split("to");
			myMap.put(63,b[1]);
		}
  		
	  }catch(Exception e) {
          System.out.println("exception"+e.getMessage());
       }
		return myMap;
	}
	
	
	 
}

