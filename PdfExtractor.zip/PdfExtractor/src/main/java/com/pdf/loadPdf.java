package com.pdf;

import java.io.File;

public class loadPdf {
		
		public File loadfile(String path) {
			File file = new File(path);
			return file;
		}

}
