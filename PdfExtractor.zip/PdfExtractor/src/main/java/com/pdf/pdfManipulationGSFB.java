package com.pdf;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class pdfManipulationGSFB {
	
		
	public HashMap<Integer, String> getFields1(String[] arr,int pdfNum, String fname,String pdfType) {
		HashMap<Integer,String> myMap=new HashMap<Integer,String>();
		List<String> arr1 = Arrays.asList(arr);
	
      try {
          
    	String sMeterreading;
    	//String pdfType;
    	
    	//put the filename into the map - 1
    	{
    		myMap.put(1,fname.trim());
    	}
    	
   	
  		//Service Type - 6
  		{
  			if(pdfType.equalsIgnoreCase("Fixed Rate General Service")) {
  				//pdfType = "RSFB";
  				myMap.put(6,"GSFB");
  			}	
  		}
  		
    	//logic for USAGE field - 17
  		{
  		int a = arr1.indexOf("Days In Billing Period")+1;
  		String b[] = arr1.get(a).toString().trim().split(" ");
  		myMap.put(19,b[0].replace(",",""));
  		
  		//to be reused for other fields
  		sMeterreading = b[0].replace(",","");
  		}
  			
  		//Meter #  18
  		{
  		int a = arr1.indexOf("Meter Reading")+1;
  		String b[] = arr1.get(a).toString().trim().split(" ");
  		String[] c= b[5].replace(",","").split(sMeterreading);
  		myMap.put(20,c[1].replace(",",""));	
  		}

  		//Customer Name -2
  		{
  			int a = arr1.indexOf("Page  of 1 2")+1;
  			String b = arr1.get(a).replaceAll("[0-9]|-", "").trim();
  			myMap.put(2,b);
  		}
  		
  		//account number and web access code 3,4
  		{
  			int a = arr1.indexOf("Emergencies: 24hrs/7 days")+1;
  			String b[] = arr1.get(a).toString().trim().split(":");
  			String c[] = arr1.get(a+1).toString().trim().split(":");
  			myMap.put(3,b[1].trim());
  			myMap.put(4,c[1]);
  		}
  		
  		//Get Service Address 5
  		{
  			int a = arr1.indexOf("Service Address")+1;
  			String b = arr1.get(a).toString().trim();
  			myMap.put(5,b);
  		}
  		
  		//Get Service Period 7
  		{
  			int a = arr1.indexOf("Service Period")+1;
  			String b = arr1.get(a).toString().trim();
  			myMap.put(7,b);
  		}
  		
  		//Get Pervious Bill Amount 8 
  		{
  		int a = arr1.indexOf("Billing Summary")+1;
  		String b[] = arr1.get(a).toString().trim().split("Amount");
  		myMap.put(8,b[1]);	
  		}
  		
  		//Get Payment REceived On #1 and Amount 9,10
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Payment Received On.*");
  			String a = b.get(0).toString().trim();
  			String c = StringUtils.right(a, 8);
  			myMap.put(9,c);
  			myMap.put(10,"$"+StringUtils.substringBetween(a, "-", c));
  		}
  		
  		//Get Budget Billing/ Current Electric Service -11
  		
  		//Total Due 12
  		{
  			//int a = arr1.indexOf("Total Due")+1;
  			//String b[] = arr1.get(a).toString().trim().split(" ");
  			//myMap.put(12,"$"+b[1].toString().trim());
  	  		//Fixed Rate 21
  	  		
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total Due.*");
  			if(b.isEmpty()) {
  				myMap.put(12,"");
  			}else {
  				String[] a = b.get(0).toString().trim().split("\\$");
  				myMap.put(12,"$"+a[1].toString().trim());
  			}
  		
  			
  		}
  		
  		//State Sales Tax - Lighting -13
  		{	
  			
  	  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Lighting.*");
  	  			if(b.isEmpty()) {
  	  				myMap.put(13,"0");
  	  			}else {
  	  			String[] a = b.get(0).toString().trim().split("Lighting");
  	  			myMap.put(13,"$"+a[1].toString().trim());
  	  			}
  			}
   		
  		
  		//Get Florida Gross Receipts tax -14
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Florida Gross Receipts Tax.*");
  			if(b.isEmpty()) {
  				myMap.put(14,"0");
  			}else {
  			String[] a = b.get(0).toString().trim().split("Tax");
  			myMap.put(14,"$"+a[1].toString().trim());
  			}
  		}
  		
  		//Get Franchise Fee - 15
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Franchise Fee.*");
  			if(b.isEmpty()) {
  				myMap.put(15,"0");
  			}else {
  				String[] a = b.get(0).toString().trim().split(" ");
  	  			myMap.put(15,"$"+a[a.length-1].trim().toString().trim());
  			}
  		}
  		
  		//Total Electric Service 16
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total Current Electric.*");
  			if(b.isEmpty()) {
  				myMap.put(18,"0");
  			}else {
  				String[] a = b.get(0).toString().trim().split("\\$");
  				myMap.put(18,"$"+a[1].toString().trim());
  			}
  		}
  		

  		
  		//Current reading and Previous reading 19,20
  		{
  			int a = arr1.indexOf("Meter Reading")+1;
  			String c[] = arr1.get(a).toString().trim().split("kWh");
  			String b[] = c[1].toString().trim().split(" ");
  			myMap.put(21,b[0].toString().trim());
  			myMap.put(22,b[1].toString().trim());
  			
  		}
  		
  		//Fixed Rate 23
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Fixed Rate \\$.*");
  			if(b.isEmpty()) {
  				myMap.put(23,"0");
  			}else {
  				String[] a = b.get(0).toString().trim().split("\\$");
  				myMap.put(23,"$"+a[1].toString().trim());
  			}
  		}
    	
  		//State Sales Tax
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*State Sales Tax.*");
  			if(b.isEmpty()) {
  				myMap.put(16,"0");
  			}else {
  				if(b.get(0).toString().contains("Lighting")) {
  					String[] a = b.get(1).toString().trim().split(" ");
  		  			myMap.put(16,"$"+a[a.length-1].trim().toString().trim());
  				}else {
  					String[] a = b.get(0).toString().trim().split(" ");
  		  			myMap.put(16,"$"+a[a.length-1].trim().toString().trim());
  				}
  			}
  		}
  		
  		//Get County Sales Tax
  		{	
  			
  	  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*County Local Sales Tax.*");
  	  			if(b.isEmpty()) {
  	  				myMap.put(17,"0");
  	  			}else {
  	  			String[] a = b.get(0).toString().trim().split(" ");
  	  			myMap.put(17,"$"+a[4].toString().trim());
  	  			}
  			
  			
  		}
  		
  		//yet to code
  		myMap.put(11," ");//Current Electric Service
  		
  		
       } catch(ArrayIndexOutOfBoundsException e) {
          System.out.println(e.getMessage());
       }
		
	
		return myMap;
	}
	
	
	public HashMap<Integer, String> getFields2(String[] arr,int pdfNum, String fname, String pdfType) {
		HashMap<Integer,String> myMap=new HashMap<Integer,String>();
		List<String> arr1 = Arrays.asList(arr);
		
		 try {
	          //String pdfType;
		//put the name into the map
		{
			myMap.put(1,fname.trim());
		}
			 
		
		//Get Service Type
		/*{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Rate:.*");
			String a = b.get(0).toString().trim();
			String c = StringUtils.substringBetween(a, ":","-").trim();
			myMap.put(6,c);
			pdfType = c;
		}*/
		
		//logic to handle short forms of service types
  		{
  			if(pdfType.equalsIgnoreCase("RSFB")) {
  				//pdfType = "RS";
  				myMap.put(6,"RSFB");
  		}}
		
		
		//Get Usage
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"kWh used.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(19,a[2].toString().trim());
		}
		
		//Meter No
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Meter reading - Meter.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(20,a[4].toString().trim().replaceAll("\\.", ""));
		}
		
		//Name
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Hello.*");
			String[] a = b.get(0).toString().trim().split("Hello");
			myMap.put(2,a[1].toString().trim().replaceAll(",",""));
		}
		
		//Account number
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Account Number:.*");
			String[] a = b.get(0).toString().trim().split(":");
			myMap.put(3,a[1].toString().trim());
		}
		
		//Web Access code
		{
			myMap.put(4,"N/A");
		}
		
		//Service Address:
		{
			int a = arr1.indexOf("Service Address:")+1;
			String b = arr1.get(a).trim();
			myMap.put(5,b);
		}
		
		//Get Service Period 7
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"For.*");
			String[] a = b.get(0).toString().trim().split(":");
			String[] c = a[1].split("\\(");
			myMap.put(7,c[0].toString().trim().replaceAll("to","-"));
		}
		
		//Amount of your last bill
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Amount of your last bill.*");
			String[] a = b.get(0).toString().trim().split("last bill");
			myMap.put(8,"$"+a[1].toString().trim());
		}
		
		
		//Last Payment recived on
		{
			myMap.put(9,"N/A");
		}
		
		//Get Florida Gross Receipts tax Gross Receipts 3.01
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Gross receipts.*");
			if(b.isEmpty()) {
				 b = new pdfUtility().getMatchingStrings(arr1,"Gross Receipts.*");
				 String[] a = b.get(0).toString().trim().split("Receipts");
	  			myMap.put(14,"$"+a[1].toString().trim());
 			}else {
 				String[] a = b.get(0).toString().trim().split("tax");
 				myMap.put(14,"$"+a[1].toString().trim());
 			}

		}
		
		
		
		//Franchise Fee City 
		{	
			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Franchise charge.*");
			if(b.isEmpty()) {
				 b = new pdfUtility().getMatchingStrings(arr1,".*Franchise Fee.*");
				 if(b.isEmpty()) {
					 myMap.put(15,"N/A");
				 }else {
				 String[] a = b.get(0).toString().trim().split("Fee");
	  			myMap.put(15,"$"+a[1].toString().trim());}
  			}else {
  				String[] a = b.get(0).toString().trim().split("charge");
  				myMap.put(15,"$"+a[1].toString().trim());
  			}	
		}

		//Get  Total Electric Service 23
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total new charges.*");
			String[] a = b.get(0).toString().trim().split("charges");
			myMap.put(16,"$"+a[1].toString().trim());
		}
		
		//Total Due 13
		{
			int a = arr1.indexOf("CURRENT BILL")+1;
			String b = arr1.get(a).trim();
			myMap.put(12,b);
		}
		
		//Payment Received Amount 10
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*received.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(10,"$"+a[a.length-1].toString().trim().substring(1));
		}
		
		
  		//yet to code
  		myMap.put(11," "); //Current Electric Service
  		myMap.put(13," "); //Lighting - State Sales Tax
  		myMap.put(21," "); //fixed rate

		
		//current reading
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Current reading.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(21,a[2].toString().trim());	
  			
  		}
  		
  		//previous reading
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Previous reading.*");
			String[] a = b.get(0).toString().trim().split("-");
			myMap.put(22,a[1].toString().trim());		
  		}
  		
  		
	  }catch(Exception e) {
          System.out.println("exception"+e.getMessage());
       }
		return myMap;
	}
}
