package com.pdf;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class pdfManipulationOS3 {

		
	public HashMap<Integer, String> getFields1(String[] arr,int pdfNum, String fname,String pdfType) {
		HashMap<Integer,String> myMap=new HashMap<Integer,String>();
		List<String> arr1 = Arrays.asList(arr);
	
      try {
          
    	String sMeterreading;
    	//String pdfType;
    	
    	//put the filename into the map
    	{
    		myMap.put(1,fname.trim());
    	}
    	
  		//Get Service Type with two types
  		/*{	
  			
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Current Electric Service -.*");
  			if(b.isEmpty()) {
  				int a = arr1.indexOf("Current Electric Service")+2;
  	  			String c = arr1.get(a).toString().trim().substring(0, 2);
  	  			myMap.put(6,c);
  	  			pdfType = c;
  			}else {
	  			String[] a = b.get(0).toString().trim().split("-");
	  			myMap.put(6,a[1].toString().trim());
	  			pdfType = myMap.get(6);
  			}	
  		}*/
    	
  		//logic to handle short forms of service types
  		{
  			if(pdfType.equalsIgnoreCase("OS3")) {
  				//pdfType = "RS";
  				myMap.put(6,"OS3");
  			}	
  		}
  		
    	//logic for USAGE field - 24
  		{
  		int a = arr1.indexOf("Meter Reading")+1;
  		String b[] = arr1.get(a).toString().trim().split(" ");
  		String c = b[5].replace("Tot", "").trim();
  		myMap.put(24,c);
  		
  		//to be reused for other fields
  		sMeterreading = c;
  		}
  			
  		//Meter # Sep 6 - Oct 8 2,0005853270 Tot kWh 89876 87876 1  - use Usage
  		{
				/*
				 * int a = arr1.indexOf("Meter Reading")+1; String b[] =
				 * arr1.get(a).toString().trim().split(" "); String[] c=
				 * b[5].replace(",","").split(sMeterreading);
				 * myMap.put(25,c[1].replace(",",""));
				 */myMap.put(25,"NA");
  		}

  		//Customer Name
  		{
  			int a = arr1.indexOf("Page  of 1 2")+1;
  			String b = arr1.get(a).replaceAll("[0-9]|-", "").trim();
  			myMap.put(2,b);
  		}
  		
  		//account number and web access code
  		{
  			int a = arr1.indexOf("Emergencies: 24hrs/7 days")+1;
  			String b[] = arr1.get(a).toString().trim().split(":");
  			String c[] = arr1.get(a+1).toString().trim().split(":");
  			myMap.put(3,b[1].trim());
  			myMap.put(4,c[1]);
  		}
  		
  		//Get Service Address 5
  		{
  			int a = arr1.indexOf("Service Address")+1;
  			String b = arr1.get(a).toString().trim();
  			myMap.put(5,b);
  		}
  		
  		//Get Service Period 7
  		{
  			int a = arr1.indexOf("Service Period")+1;
  			String b = arr1.get(a).toString().trim();
  			myMap.put(7,b);
  		}
  		
  		//Get Pervious Bill Amount
  		{
  		int a = arr1.indexOf("Billing Summary")+1;
  		String b[] = arr1.get(a).toString().trim().split("Amount");
  		myMap.put(8,b[1]);	
  		}
  		
  		//Get Payment REceived On #1 and Amount
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Payment Received On.*");
  			String a = b.get(0).toString().trim();
  			String c = StringUtils.right(a, 8);
  			myMap.put(9,c);
  			myMap.put(10,"$"+StringUtils.substringBetween(a, "-", c));
  		}
  		
  		//Get Budget Billing/ Current Electric Service
  		

  		
  		//Get Base Charge
  		{	
  			
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Base Charge.*");
  	  		if(b.isEmpty()) {
  				myMap.put(12,"");
  			}else {
  				String[] a = b.get(0).toString().trim().split("\\$");
  	  			myMap.put(12,"$"+a[1].toString().trim());
  			}
  			
  		}
  		
  		//Get Energy Charge
  		{	
 			
 	  			List<String> c = new pdfUtility().getMatchingStrings(arr1,"Energy Charge.*");
 	  			String[] d = c.get(0).toString().trim().split(" ");
 	  			myMap.put(15,"$"+d[2].toString().trim().replace(sMeterreading,""));
  			
  		 	//int a = arr1.indexOf("Days In Billing Period")+1;
  			//String b[] = arr1.get(a).toString().trim().split(" ");
  			//String sMeterreading = b[0].replace(",","");
  		}
  		
  		//Get Fuel Charge
  		{
  			//int a = arr1.indexOf("Days In Billing Period")+1;
  			//String b[] = arr1.get(a).toString().trim().split(" ");
  			//String sMeterreading = b[0].replace(",","");
  			
  			
  				List<String> c = new pdfUtility().getMatchingStrings(arr1,"Fuel Charge.*");
  	  			String[] d = c.get(0).toString().trim().split(" ");
  	  			myMap.put(16,"$"+d[2].toString().trim().replace(sMeterreading,""));
  			
  		}
  		
  		
  		//Get Subtotal 
  		{	
  			
  				List<String> b = new pdfUtility().getMatchingStrings(arr1,"Subtotal of Electric Service.*");
  	  			String[] a = b.get(0).toString().trim().split("\\$");
  	  			myMap.put(17,"$"+a[1].toString().trim());
  			
  		}
  		
  		//State Sales Tax - Lighting
  		{	
  			
  	  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Lighting.*");
  	  			if(b.isEmpty()) {
  	  				myMap.put(18,"0");
  	  			}else {
  	  			String[] a = b.get(0).toString().trim().split("Lighting");
  	  			myMap.put(18,"$"+a[1].toString().trim());
  	  			}
  			
  		}
  		
  		//Get County Sales Tax
  		{	
  			
  	  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*County Local Sales Tax.*");
  	  			if(b.isEmpty()) {
  	  				myMap.put(22,"0");
  	  			}else {
  	  			String[] a = b.get(0).toString().trim().split(" ");
  	  			myMap.put(22,"$"+a[4].toString().trim());
  	  			}
  			
  			
  		}
  		
  		
  		//Get Florida Gross Receipts tax
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Florida Gross Receipts Tax.*");
  			if(b.isEmpty()) {
  				myMap.put(19,"0");
  			}else {
  			String[] a = b.get(0).toString().trim().split("Tax");
  			myMap.put(19,"$"+a[1].toString().trim());
  			}
  		}
  		
  		//Get Franchise Fee
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Franchise Fee.*");
  			if(b.isEmpty()) {
  				myMap.put(20,"0");
  			}else {
  				String[] a = b.get(0).toString().trim().split(" ");
  	  			myMap.put(18,"$"+a[a.length-1].trim().toString().trim());
  			}
  		}
  		
  		//Total Electric Service 23
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total Current Electric.*");
  			if(b.isEmpty()) {
  				myMap.put(23,"0");
  			}else {
  				String[] a = b.get(0).toString().trim().split("\\$");
  				myMap.put(23,"$"+a[1].toString().trim());
  			}
  		}
  		
  		//Total Due
  		{
  			int a = arr1.indexOf("Total Due")+1;
  			String b[] = arr1.get(a).toString().trim().split(" ");
  			myMap.put(13,"$"+b[1].toString().trim());
  			
  		}
  		
  		//Current reading and Previous reading
  		{
  			int a = arr1.indexOf("Meter Reading")+1;
  			String c[] = arr1.get(a).toString().trim().split("kWh");
  			String b[] = c[1].toString().trim().split(" ");
  			myMap.put(26,b[0].toString().trim());
  			myMap.put(27,b[1].toString().trim());
  			
  		}
    	
  		//yet to code due to insufficient data
  		myMap.put(11," "); //Current Electric Service
  		myMap.put(12," "); //Budget Billing
  		myMap.put(21," "); //State Sales Tax
  		
  		
       } catch(ArrayIndexOutOfBoundsException e) {
          System.out.println(e.getMessage());
       }
		
	
		return myMap;
	}
	
	
	public HashMap<Integer, String> getFields2(String[] arr,int pdfNum, String fname, String pdfType) {
		HashMap<Integer,String> myMap=new HashMap<Integer,String>();
		List<String> arr1 = Arrays.asList(arr);
		
		 try {
	          //String pdfType;
		//put the name into the map
		{
			myMap.put(1,fname.trim());
		}
			 
		
		//Get Service Type
		/*{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Rate:.*");
			String a = b.get(0).toString().trim();
			String c = StringUtils.substringBetween(a, ":","-").trim();
			myMap.put(6,c);
			pdfType = c;
		}*/
		
		//logic to handle short forms of service types
  		{
  			if(pdfType.equalsIgnoreCase("RS")) {
  				//pdfType = "RS";
  				myMap.put(6,"RS");
  			}
  			else if(pdfType.equalsIgnoreCase("Fixed Rate Residential Service")) {
  				//pdfType = "RSFB";
  				myMap.put(6,"RSFB");
  			}
  		}
		
		
		//Get Usage
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"kWh used.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(24,a[2].toString().trim());
		}
		
		//Meter No
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Meter reading - Meter.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(25,a[4].toString().trim().replaceAll("\\.", ""));
		}
		
		//Name
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Hello.*");
			String[] a = b.get(0).toString().trim().split("Hello");
			myMap.put(2,a[1].toString().trim().replaceAll(",",""));
		}
		
		//Account number
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Account Number:.*");
			String[] a = b.get(0).toString().trim().split(":");
			myMap.put(3,a[1].toString().trim());
		}
		
		//Web Access code
		{
			myMap.put(4,"N/A");
		}
		
		//Service Address:
		{
			int a = arr1.indexOf("Service Address:")+1;
			String b = arr1.get(a).trim();
			myMap.put(5,b);
		}
		
		//Get Service Period 7
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"For.*");
			String[] a = b.get(0).toString().trim().split(":");
			String[] c = a[1].split("\\(");
			myMap.put(7,c[0].toString().trim().replaceAll("to","-"));
		}
		
		//Amount of your last bill
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Amount of your last bill.*");
			String[] a = b.get(0).toString().trim().split("last bill");
			myMap.put(8,"$"+a[1].toString().trim());
		}
		

		
		//Base Charge
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Base charge.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(14,"$"+a[2].toString().trim());
		}
		
		//Energy Charge [Energy charges all inclusive 852 KWH at $0.08397 71.54]
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Energy charge.*");
			String[] a = b.get(0).toString().trim().split("at");
			String[] c = a[1].trim().split(" ");
			myMap.put(15,"$"+c[1].toString().trim());
		}
		
		//Fuel Charge [Fuel charge 852 KWH at $0.03047 25.96]
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Fuel charge.*");
			String[] a = b.get(0).toString().trim().split("at");
			String[] c = a[1].trim().split(" ");
			myMap.put(16,"$"+c[1].toString().trim());
		}
		
		//Get SubTotal
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Electric service amount .*");
			String[] a = b.get(0).toString().trim().split("amount");
			myMap.put(17,a[1].toString().trim());
		}
		
		//State Sales Tax
		{
			myMap.put(18,"N/A");
		}
		
		//Last Payment recived on
		{
			myMap.put(9,"N/A");
		}
		
		//Get Florida Gross Receipts tax Gross Receipts 3.01
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Gross receipts.*");
			if(b.isEmpty()) {
				 b = new pdfUtility().getMatchingStrings(arr1,"Gross Receipts.*");
				 String[] a = b.get(0).toString().trim().split("Receipts");
	  			myMap.put(19,"$"+a[1].toString().trim());
 			}else {
 				String[] a = b.get(0).toString().trim().split("tax");
 				myMap.put(19,"$"+a[1].toString().trim());
 			}

		}
		
		
		
		//Franchise Fee City Franchise Fee 6.18
		{	
			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Franchise charge.*");
			if(b.isEmpty()) {
				 b = new pdfUtility().getMatchingStrings(arr1,".*Franchise Fee.*");
				 String[] a = b.get(0).toString().trim().split("Fee");
	  			myMap.put(20,"$"+a[1].toString().trim());
  			}else {
  				String[] a = b.get(0).toString().trim().split("charge");
  				myMap.put(20,"$"+a[1].toString().trim());
  			}	
		}

		//Get  Total Electric Service 23
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total new charges.*");
			String[] a = b.get(0).toString().trim().split("charges");
			myMap.put(23,"$"+a[1].toString().trim());
		}
		
		//Total Due 13
		{
			int a = arr1.indexOf("CURRENT BILL")+1;
			String b = arr1.get(a).trim();
			myMap.put(13,b);
		}
		
		//Payment Received Amount 10
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*received.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(10,"$"+a[a.length-1].toString().trim().substring(1));
		}
		
		
  		//yet to code
  		myMap.put(11," ");//Current Electric Service
  		myMap.put(12," ");//Budget Billing
  		myMap.put(21," ");//State Sales Tax
  		myMap.put(22," ");//County Sales Tax
		
		//current reading
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Current reading.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(26,a[2].toString().trim());	
  			
  		}
  		
  		//previous reading
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Previous reading.*");
			String[] a = b.get(0).toString().trim().split("-");
			myMap.put(27,a[1].toString().trim());		
  		}
  		
  		
	  }catch(Exception e) {
          System.out.println("exception"+e.getMessage());
       }
		return myMap;
	}
}
