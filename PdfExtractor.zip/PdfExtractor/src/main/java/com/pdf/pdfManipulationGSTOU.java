package com.pdf;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class pdfManipulationGSTOU {
	
		
	public HashMap<Integer, String> getFields1(String[] arr,int pdfNum, String fname,String pdfType) {
		HashMap<Integer,String> myMap=new HashMap<Integer,String>();
		List<String> arr1 = Arrays.asList(arr);
	
      try {
          
    	String sMeterreading;
    	//String pdfType;
    	
    	//put the filename into the map - 1
    	{
    		myMap.put(1,fname.trim());
    	}
    	
   	
  		//Service Type - 6
  		{
  			if(pdfType.equalsIgnoreCase("GSTOU")) {
  				//pdfType = "RS";
  				myMap.put(6,"GSTOU");
  			}
  		}
  		
    	//logic for USAGE field - 20
  		{
  		int a = arr1.indexOf("Days In Billing Period")+1;
  		String b[] = arr1.get(a).toString().trim().split(" ");
  		myMap.put(20,b[0].replace(",",""));
  		
  		//to be reused for other fields
  		sMeterreading = b[0].replace(",","");
  		}
  			
  		//Meter #  21
  		{
  		
  		int a = arr1.indexOf("Meter Reading")+1;
  		String b[] = arr1.get(a).toString().trim().split(" ");
  		//String d= b[5];
  		String c = StringUtils.right(b[5], 7);
  		myMap.put(21,c);	
  		
  		}

  		//Customer Name -2
  		{
  			int a = arr1.indexOf("Page  of 1 2")+1;
  			String b = arr1.get(a).replaceAll("[0-9]|-", "").trim();
  			myMap.put(2,b);
  		}
  		
  		//account number and web access code 3,4
  		{
  			int a = arr1.indexOf("Emergencies: 24hrs/7 days")+1;
  			String b[] = arr1.get(a).toString().trim().split(":");
  			String c[] = arr1.get(a+1).toString().trim().split(":");
  			myMap.put(3,b[1].trim());
  			myMap.put(4,c[1]);
  		}
  		
  		//Get Service Address 5
  		{
  			int a = arr1.indexOf("Service Address")+1;
  			String b = arr1.get(a).toString().trim();
  			myMap.put(5,b);
  		}
  		
  		//Get Service Period 7
  		{
  			int a = arr1.indexOf("Service Period")+1;
  			String b = arr1.get(a).toString().trim();
  			myMap.put(7,b);
  		}
  		
  		//Get Pervious Bill Amount 8 
  		{
  		int a = arr1.indexOf("Billing Summary")+1;
  		String b[] = arr1.get(a).toString().trim().split("Amount");
  		myMap.put(8,b[1]);	
  		}
  		
  		//Get Payment REceived On #1 and Amount 9,10
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Payment Received On.*");
  			String a = b.get(0).toString().trim();
  			String c = StringUtils.right(a, 8);
  			myMap.put(9,c);
  			myMap.put(10,"$"+StringUtils.substringBetween(a, "-", c));
  		}
  		
  		//Get Budget Billing/ Current Electric Service -11
  		
  		//Total Due 12
  		{
  			//int a = arr1.indexOf("Total Due")+1;
  			//String b[] = arr1.get(a).toString().trim().split(" ");
  			//myMap.put(12,"$"+b[1].toString().trim());
  	  		//Fixed Rate 21
  	  		
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total Due.*");
  			if(b.isEmpty()) {
  				myMap.put(12,"");
  			}else {
  				String[] a = b.get(0).toString().trim().split("\\$");
  				myMap.put(12,"$"+a[1].toString().trim());
  			}
  		
  			
  		}
  		
  		//Get Base Charge 13
  		{	
  				List<String> b = new pdfUtility().getMatchingStrings(arr1,"Base Charge.*");
  	  			String[] a = b.get(0).toString().trim().split("\\$");
  	  			myMap.put(13,"$"+a[1].toString().trim());	
  		}
  		
  		//Get Fuel Charge 14
  		{	
  				List<String> c = new pdfUtility().getMatchingStrings(arr1,"Fuel Charge.*");
  	  			String[] d = c.get(0).toString().trim().split(" ");
  	  			myMap.put(14,"$"+d[2].toString().trim().replace(sMeterreading,"")); 			
  		}
  		
  		//Get Subtotal 15
  		{	
  				List<String> b = new pdfUtility().getMatchingStrings(arr1,"Subtotal of Electric Service.*");
  	  			String[] a = b.get(0).toString().trim().split("\\$");
  	  			myMap.put(15,"$"+a[1].toString().trim());
  		}
  		
	
  		//State Sales Tax - Lighting -16
  		{	
  			
  	  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Lighting.*");
  	  			if(b.isEmpty()) {
  	  				myMap.put(16,"0");
  	  			}else {
  	  			String[] a = b.get(0).toString().trim().split("Lighting");
  	  			myMap.put(16,"$"+a[1].toString().trim());
  	  			}
  			}
   		
  		
  		//Get Florida Gross Receipts tax -17
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Florida Gross Receipts Tax.*");
  			if(b.isEmpty()) {
  				myMap.put(17,"0");
  			}else {
  			String[] a = b.get(0).toString().trim().split("Tax");
  			myMap.put(17,"$"+a[1].toString().trim());
  			}
  		}
  		
  		//Get Franchise Fee - 18
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Franchise Fee.*");
  			if(b.isEmpty()) {
  				myMap.put(18,"0");
  			}else {
  				String[] a = b.get(0).toString().trim().split(" ");
  	  			myMap.put(18,"$"+a[a.length-1].trim().toString().trim());
  			}
  		}
  		
  		//Total Electric Service 19
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total Current Electric.*");
  			if(b.isEmpty()) {
  				myMap.put(19,"0");
  			}else {
  				String[] a = b.get(0).toString().trim().split("\\$");
  				myMap.put(19,"$"+a[1].toString().trim());
  			}
  		}
  		
  		//Budget Billing
  		{
  			
  		}
  		
  		//On Peak Energy Charge 25
  		{

  			myMap.put(25,"NA");
  		}
  		
  		//Off Peak Energy Charge 26
  		{

  			myMap.put(26,"NA");
  		}
    	
  		//yet to code
  		myMap.put(11," ");//Current Electric Service
  		myMap.put(24,"NA");//Budget Billing
  		myMap.put(22,"NA");//Current reading 		
  		myMap.put(23,"NA");//previous Reading
  		
  		
  		
       } catch(ArrayIndexOutOfBoundsException e) {
          System.out.println(e.getMessage());
       }
		
	
		return myMap;
	}
	
	
	public HashMap<Integer, String> getFields2(String[] arr,int pdfNum, String fname, String pdfType) {
		HashMap<Integer,String> myMap=new HashMap<Integer,String>();
		List<String> arr1 = Arrays.asList(arr);
		
		 try {
	          //String pdfType;
		//put the name into the map
		{
			myMap.put(1,fname.trim());
		}
			 
		
		//Get Service Type
		/*{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Rate:.*");
			String a = b.get(0).toString().trim();
			String c = StringUtils.substringBetween(a, ":","-").trim();
			myMap.put(6,c);
			pdfType = c;
		}*/
		
		//logic to handle short forms of service types
  		{
  			if(pdfType.equalsIgnoreCase("RS")) {
  				//pdfType = "RS";
  				myMap.put(6,"RS");
  			}
  			else if(pdfType.equalsIgnoreCase("Fixed Rate Residential Service")) {
  				//pdfType = "RSFB";
  				myMap.put(6,"RSFB");
  			}
  			else if(pdfType.equalsIgnoreCase("RSTOU")) {
  				//pdfType = "RSFB";
  				myMap.put(6,"RSTOU");
  			}
  		}
		
		
		//Get Usage
		{
			List<String> b = new pdfUtility().getMatchingStringsignorecase(arr1,".*kWh used.*");
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(20,a[2].toString().trim());
		}
		
		//Meter No
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Meter reading - Meter.*");
			if(b.isEmpty()) {myMap.put(21,"NA");}
			else {
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(21,a[4].toString().trim().replaceAll("\\.", ""));
			}
		}
		
		//Name
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Hello.*");
			String[] a = b.get(0).toString().trim().split("Hello");
			myMap.put(2,a[1].toString().trim().replaceAll(",",""));
		}
		
		//Account number
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Account Number:.*");
			String[] a = b.get(0).toString().trim().split(":");
			myMap.put(3,a[1].toString().trim());
		}
		
		//Web Access code
		{
			myMap.put(4,"N/A");
		}
		
		//Service Address:
		{
			int a = arr1.indexOf("Service Address:")+1;
			String b = arr1.get(a).trim();
			myMap.put(5,b);
		}
		
		//Get Service Period 7
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"For.*");
			String[] a = b.get(0).toString().trim().split(":");
			String[] c = a[1].split("\\(");
			myMap.put(7,c[0].toString().trim().replaceAll("to","-"));
		}
		
		//Amount of your last bill
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Amount of your last bill.*");
			if(b.isEmpty()) {myMap.put(8,"NA");}
			else {
			String[] a = b.get(0).toString().trim().split("last bill");
			myMap.put(8,"$"+a[1].toString().trim());
			}
		}
		

		
		//Base Charge
		{
			List<String> b = new pdfUtility().getMatchingStringsignorecase(arr1,"Base charge.*");
			if(b.isEmpty()) {myMap.put(13,"NA");}
			else {
			String[] a = b.get(0).toString().trim().split(" ");
			myMap.put(13,"$"+a[2].toString().trim());
			}
		}
		
		
		//Fuel Charge 
		{
			List<String> b = new pdfUtility().getMatchingStringsignorecase(arr1,"Fuel charge.*");
			String[] a = b.get(0).toString().trim().split(" ");
			String c = a[a.length-1].trim();
			myMap.put(14,"$"+c);
		}
		
		//Get SubTotal
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Electric service amount .*");
			String[] a = b.get(0).toString().trim().split("amount");
			myMap.put(15,a[1].toString().trim());
		}
		
		
		//Payment recived on
		{
			myMap.put(9,"N/A");
		}
		
		//Get Florida Gross Receipts tax Gross Receipts 3.01
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Gross receipts.*");
			if(b.isEmpty()) {
				 b = new pdfUtility().getMatchingStrings(arr1,"Gross Receipts.*");
				 String[] a = b.get(0).toString().trim().split("Receipts");
				 myMap.put(17,"$"+a[1].toString().trim());
 			}else {
 				String[] a = b.get(0).toString().trim().split("tax");
 				myMap.put(17,"$"+a[1].toString().trim());
 			}

		}
		
		
		
		//Franchise Fee City Franchise Fee 6.18
		{	
			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*Franchise charge.*");
			if(b.isEmpty()) {
				 b = new pdfUtility().getMatchingStrings(arr1,".*Franchise Fee.*");
				 String[] a = b.get(0).toString().trim().split("Fee");
	  			myMap.put(18,"$"+a[1].toString().trim());
  			}else {
  				String[] a = b.get(0).toString().trim().split("charge");
  				myMap.put(18,"$"+a[1].toString().trim());
  			}	
		}

		//Total Electric Service 19
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Total new charges.*");
			String[] a = b.get(0).toString().trim().split("charges");
			myMap.put(19,"$"+a[1].toString().trim());
		}
		
		//Total Due 12
		{
			int a = arr1.indexOf("CURRENT BILL")+1;
			String b = arr1.get(a).trim();
			myMap.put(12,b);
		}
		
		//Payment Received Amount 10
		{
			List<String> b = new pdfUtility().getMatchingStrings(arr1,".*received.*");
			if(b.isEmpty()) {
	  			myMap.put(10,"NA");
 			}else {
 				String[] a = b.get(0).toString().trim().split(" ");
 				myMap.put(10,"$"+a[a.length-1].toString().trim().substring(1));
 			}		
		}
		
		
		//current reading
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Current reading.*");
			if(b.isEmpty()) {
	  			myMap.put(22,"NA");
 			}else {
 				String[] a = b.get(0).toString().trim().split(" ");
 				myMap.put(22,a[2].toString().trim());
 			}	 			
  		}
  		
  		//previous reading
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Previous reading.*");
			if(b.isEmpty()) {
	  			myMap.put(23,"NA");
 			}else {
 				String[] a = b.get(0).toString().trim().split("-");
 				myMap.put(23,a[1].toString().trim());
 			}				
  		}
  		
  		//on peak
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"On Peak.*");
			if(b.isEmpty()) {
	  			myMap.put(25,"NA");
 			}else {
 				String[] a = b.get(0).toString().trim().split(" ");
 				myMap.put(25,"$"+a[a.length-1].toString().trim());
 			}				
  		}
  		
  		//off peak
  		{
  			List<String> b = new pdfUtility().getMatchingStrings(arr1,"Off Peak.*");
			if(b.isEmpty()) {
	  			myMap.put(26,"NA");
 			}else {
 				String[] a = b.get(0).toString().trim().split(" ");
 				myMap.put(26,"$"+a[a.length-1].toString().trim());
 			}				
  		}
  		
  		
  	//	{1=GERSTOU_SAP.pdf, 2=Nellie L Lanphere, 3=25000-00921, 4=N/A, 5=11369 OLD BARN LN, 6=RSTOU, 7=Aug 8, 2019 - Sep 9, 2019, 8=NA, 9=N/A, 10=NA, 11= , 12=$22.77, 13=$21.12, 14=$0.00, 15=$21.12, 16= , 17=$0.54, 18=$1.11, 19=$22.77, 20=0, 21=NA, 22=NA, 23=NA, 24= , 25=$.00, 26=$.00
  		
  		//yet to code
  		myMap.put(11," ");
  		myMap.put(16," ");
  		myMap.put(24," ");
  		
  		
	  }catch(Exception e) {
          System.out.println("exception"+e.getMessage());
       }
		return myMap;
	}
}
