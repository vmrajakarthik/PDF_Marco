package com.pdf;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.List;
public class pdfUtility {
	
	public String pmatcher(String str, String Regx) {
		String mydata = str.trim();
		Pattern pattern = Pattern.compile(Regx);
		Matcher matcher = pattern.matcher(mydata);
		return matcher.group(1);
	}
	
	public List<String> getMatchingStrings(List<String> list, String regex) {

		  ArrayList<String> matches = new ArrayList<String>();
		  Pattern p = Pattern.compile(regex);

		  for (String s:list) {
		    if (p.matcher(s).matches()) {
		      matches.add(s);
		    }
		  }
		  return matches;
		}
	
	public List<Integer> getMatchingStringsindex(List<String> list, String regex) {

		  //ArrayList<String> matches = new ArrayList<String>();
		  ArrayList<Integer> matches1 = new ArrayList<Integer>();
		  Pattern p = Pattern.compile(regex);
		  
		  for (int i = 0; i < list.size(); i++) {
				if (p.matcher(list.get(i)).matches()) {
				      matches1.add(i);
				    }
			}
		  return matches1;
		}
	
	public List<String> getMatchingStringsignorecase(List<String> list, String regex) {

		  ArrayList<String> matches = new ArrayList<String>();
		  String r = "(?i:"+regex+")";
		  Pattern p = Pattern.compile(r);

		  for (String s:list) {
		    if (p.matcher(s).matches()) {
		      matches.add(s);
		    }
		  }
		  return matches;
		}
}
