package com.pdf;
import java.io.File;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.apache.pdfbox.text.PDFTextStripper;

public class readpdf {
	
	public String ReadData(File e) {
		PDDocument document;
		String text = null;
		
		try {
			document = PDDocument.load(e);
			//PDDocumentInformation pdd = document.getDocumentInformation();
			PDFTextStripper pdfStripper = new PDFTextStripper();
			text = pdfStripper.getText(document);
			
			document.close();
			return text;
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return text;
	}	
}