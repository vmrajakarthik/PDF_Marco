package com.excel;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class writeExcelDataSAP {

		public writeExcelDataSAP(String filename,String sheetname,HashMap<Integer,String> hm) throws IOException, InvalidFormatException 
		{ 
			 InputStream inp = new FileInputStream(filename); 
			    Workbook wb = WorkbookFactory.create(inp); 
			    String sheetname1;
			    //Sheet sheet = wb.getSheetAt(0);
			    sheetname1 = "SAP_Data"; 
			    Sheet sheet = wb.getSheet(sheetname1);
			    int num = sheet.getLastRowNum(); 
			    Row row = sheet.createRow(++num); 
			    //row.createCell(0).setCellValue("xyz"); 
			    int rowval = 0;
			/*
			 * for (Object value : hm.values()) {
			 * row.createCell(key.intValue()).setCellValue(value.toString()); rowval++;
			 * //System.out.println(value); }
			 */
				for (Integer key :hm.keySet()) {
					int temp = key.intValue();
					row.createCell(temp).setCellValue(hm.get(temp));
					rowval++;
				}
			    FileOutputStream fileOut = new FileOutputStream(filename); 
			    wb.write(fileOut); 
			    fileOut.close(); 
			} 

}
