package com.excel;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class writeData {
	
		public writeData(String fname) {
		
			Workbook wb = new HSSFWorkbook(); 
			  //OutputStream fileOut = new FileOutputStream(fname); 
			  
			  Sheet sheet1 = wb.createSheet("CSS_Data"); 
			  Sheet sheet2 = wb.createSheet("SAP_Data");
			  
			  //creating header 
			  Map<String, Object[]> data = new TreeMap<String, Object[]>(); 
			  Map<String, Object[]> data1 = new TreeMap<String, Object[]>(); 
			  data.put("1", new Object[]{"CSS-0","CSS-1","CSS-2","CSS-3","CSS-4","CSS-5","CSS-6","CSS-7","CSS-8","CSS-9","CSS-10","CSS-11","CSS-12","CSS-13","CSS-14","CSS-15","CSS-16","CSS-17","CSS-18","CSS-19","CSS-20","CSS-21","CSS-22","CSS-23","CSS-24","CSS-25","CSS-26","CSS-27","CSS-28","CSS-29","CSS-30","CSS-31","CSS-32","CSS-33","CSS-34","CSS-35","CSS-36","CSS-37","CSS-38","CSS-39","CSS-40","CSS-41","CSS-42","CSS-43","CSS-44","CSS-45","CSS-46","CSS-47","CSS-48","CSS-49","CSS-50","CSS-51","CSS-52","CSS-53","CSS-54","CSS-55","CSS-56","CSS-57","CSS-58","CSS-59","CSS-60","CSS-61","CSS-62","CSS-63","CSS-64","CSS-65","CSS-66","CSS-67","CSS-68","CSS-69","CSS-70","CSS-71","CSS-72","CSS-73","CSS-74","CSS-75","CSS-76","CSS-77","CSS-78","CSS-79","CSS-80","CSS-81","CSS-82","CSS-83"});
			  data1.put("1", new Object[]{"SAP-0","SAP-1","SAP-2","SAP-3","SAP-4","SAP-5","SAP-6","SAP-7","SAP-8","SAP-9","SAP-10","SAP-11","SAP-12","SAP-13","SAP-14","SAP-15","SAP-16","SAP-17","SAP-18","SAP-19","SAP-20","SAP-21","SAP-22","SAP-23","SAP-24","SAP-25","SAP-26","SAP-27","SAP-28","SAP-29","SAP-30","SAP-31","SAP-32","SAP-33","SAP-34","SAP-35","SAP-36","SAP-37","SAP-38","SAP-39","SAP-40","SAP-41","SAP-42","SAP-43","SAP-44","SAP-45","SAP-46","SAP-47","SAP-48","SAP-49","SAP-50","SAP-51","SAP-52","SAP-53","SAP-54","SAP-55","SAP-56","SAP-57","SAP-58","SAP-59","SAP-60","SAP-61","SAP-62","SAP-63","SAP-64","SAP-65","SAP-66"});
			  createheader(data,sheet1,wb,fname);
			  createheader(data1,sheet2,wb,fname);
			  
			}

		public static void createheader(Map<String, Object[]> data, Sheet sheetname, Workbook objw, String fname) {
			
			 try {
			OutputStream fileOut = new FileOutputStream(fname); 
			
			// Iterate over data and write to sheet
	        Set<String> keyset = data.keySet();  
	        int rownum = 0;
	        for (String key : keyset) { 
	            Row row1 = sheetname.createRow(rownum++); 
	            Object[] objArr = data.get(key); 
	            int cellnum1 = 0;
	            for (Object obj : objArr) {  
	                Cell cell1 = row1.createCell(cellnum1++); 
	                if (obj instanceof String) {
	                	cell1.setCellValue((String)obj); }
	                else if (obj instanceof Integer) {  
	                    cell1.setCellValue((Integer)obj); 
	                }
	            } 
	        } 
	      System.out.println("Sheet headers has been Created successfully for "+sheetname.getSheetName()); 
	     
			objw.write(fileOut);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
			
		}

}

