package com.IO;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import com.excel.writeExcelDataSAP;
import com.excel.writeExcelDataCSS;
import com.pdf.pdfManipulation;
import com.pdf.pdfManipulationGS;
import com.pdf.pdfManipulationGSD;
import com.pdf.pdfManipulationGSFB;
import com.pdf.pdfManipulationGSTOU;
import com.pdf.pdfManipulationOS3;
import com.pdf.pdfManipulationRS;
import com.pdf.pdfManipulationRSFB;
import com.pdf.pdfManipulationRSTOU;
import com.pdf.pdfManipulationRSVP;
import com.pdf.readpdf;

public class inputoutput {
	
	public inputoutput(String myDirectoryPath, int flag, String fnamm) throws InvalidFormatException, IOException {
		File dir = new File(myDirectoryPath);
		  File[] directoryListing = dir.listFiles();
		  if (directoryListing != null) {
		    for (File child : directoryListing) {
		    	
		    	String sText;
		    	String[] sArray;
		    	HashMap<Integer, String> myMap;
		    	String pdffType;
		    	
		    	//System.out.println(child.getName());
		    	
		    	sText = new readpdf().ReadData(child);
		    	sArray = new pdfManipulation().toArray(sText);
		    	//System.out.println(sText);
		    	
		    	//to handle the files in folder 1
		    	if(flag==1) {
		    		
		    		//System.out.println(Arrays.asList(myMap));
		    		
		    		//get the type of CSS PFD file
		    		pdffType = new pdfManipulation().getPdfType1(sArray);
		    		
		    		//extract the data as per the file type
		    		switch(pdffType) {
		    		
		    			case "RS":
		    				myMap = new pdfManipulationRS().getFields1(sArray, 1,child.getName(),pdffType);
				    		new writeExcelDataCSS(System.getProperty("user.dir")+fnamm,"CSS",myMap);
		    				break;
	    				
					/*
					 * case "Fixed Rate Residential Service": myMap = new
					 * pdfManipulationRSFB().getFields1(sArray, 1,child.getName(),pdffType); new
					 * writeExcelDataCSS(System.getProperty("user.dir")+fnamm,"CSS",myMap); break;
					 * 
					 * case "RSTOU": myMap = new pdfManipulationRSTOU().getFields1(sArray,
					 * 1,child.getName(),pdffType); new
					 * writeExcelDataCSS(System.getProperty("user.dir")+fnamm,"CSS",myMap); break;
					 * case "RSVP": myMap = new pdfManipulationRSVP().getFields1(sArray,
					 * 1,child.getName(),pdffType); new
					 * writeExcelDataCSS(System.getProperty("user.dir")+fnamm,"CSS",myMap); break;
					 * case "GS": myMap = new pdfManipulationGS().getFields1(sArray,
					 * 1,child.getName(),pdffType); new
					 * writeExcelDataCSS(System.getProperty("user.dir")+fnamm,"CSS",myMap); break;
					 * case "Fixed Rate General Service": myMap = new
					 * pdfManipulationGSFB().getFields1(sArray, 1,child.getName(),pdffType); new
					 * writeExcelDataCSS(System.getProperty("user.dir")+fnamm,"CSS",myMap); break;
					 * case "GSD": myMap = new pdfManipulationGSD().getFields1(sArray,
					 * 1,child.getName(),pdffType); new
					 * writeExcelDataCSS(System.getProperty("user.dir")+fnamm,"CSS",myMap); break;
					 * case "GSTOU": myMap = new pdfManipulationGSTOU().getFields1(sArray,
					 * 1,child.getName(),pdffType); new
					 * writeExcelDataCSS(System.getProperty("user.dir")+fnamm,"CSS",myMap); break;
					 * case "OS3": myMap = new pdfManipulationOS3().getFields1(sArray,
					 * 1,child.getName(),pdffType); new
					 * writeExcelDataCSS(System.getProperty("user.dir")+fnamm,"CSS",myMap); break;
					 */
		    		} 			 
		    	}//to handle the files in folder 2
		    	else if(flag==2) {
		    		
		    		//get the type of SAP PFD file
		    		pdffType = new pdfManipulation().getPdfType2(sArray);
		    		
		    		//extract the data as per the file type
		    		switch(pdffType) {
		    		
		    			case "RS":
		    				
		    				myMap = new pdfManipulationRS().getFields2(sArray, 1,child.getName(),pdffType);
		    				new writeExcelDataSAP(System.getProperty("user.dir")+fnamm,"SAP",myMap);
		    				break;
		    				/*
		    			case "RSFB": 
		    				myMap = new pdfManipulationRSFB().getFields2(sArray, 1,child.getName(),pdffType);
		    				new writeExcelDataSAP(System.getProperty("user.dir")+fnamm,"SAP",myMap);
		    				break;
					
					 * case "RSTOU": myMap = new pdfManipulationRSTOU().getFields2(sArray,
					 * 1,child.getName(),pdffType); new
					 * writeExcelDataSAP(System.getProperty("user.dir")+fnamm,"SAP",myMap); break;
					 * case "RSVP": myMap = new pdfManipulationRSVP().getFields2(sArray,
					 * 1,child.getName(),pdffType); new
					 * writeExcelDataSAP(System.getProperty("user.dir")+fnamm,"SAP",myMap); break;
					 * case "GS": myMap = new pdfManipulationGS().getFields2(sArray,
					 * 1,child.getName(),pdffType); new
					 * writeExcelDataSAP(System.getProperty("user.dir")+fnamm,"SAP",myMap); break;
					 * case "GSD": myMap = new pdfManipulationGSD().getFields2(sArray,
					 * 1,child.getName(),pdffType); new
					 * writeExcelDataSAP(System.getProperty("user.dir")+fnamm,"SAP",myMap); break;
					 */    				
		    		}
		    	}   	
		    }
		  } 
		
	}
	

}
