package utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
public class propertiesfile {
		
		public String readProperties(String val) {
			Properties p=new Properties(); 
			try {
			 	FileReader reader=new FileReader("src/main/resources/config.properties"); 
			    p.load(reader);  
			     
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			 return p.getProperty(val);
		}

}
